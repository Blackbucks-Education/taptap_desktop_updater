# 3D illustrations: sources and licence

All files in this folder (and `128/`) are **Microsoft Fluent Emoji, 3D style**, unmodified except for resizing
(`128/` = downscaled with `sips -Z 128`) and format conversion. Downloaded 2026-09-26 from
https://github.com/microsoft/fluentui-emoji (`assets/<Name>/3D/<name>_3d.png`, 256×256 PNG).

Converted to WebP on 2026-10-01 (2.8 MB → 0.6 MB, visually identical at the 33–96px sizes shown):
`cwebp -q 85 -alpha_q 100 -m 6 <name>.png -o <name>.webp`. The table below still lists the source PNG
names; each is stored here as `<name>.webp`.

Licence: **MIT License**, Copyright (c) Microsoft Corporation. https://github.com/microsoft/fluentui-emoji/blob/main/LICENSE
The MIT licence permits use, copying, modification and distribution, including commercially, provided the copyright
notice and permission notice are included. Keep this file with the assets, and credit "Fluent Emoji by Microsoft
(MIT)" in the product's open-source notices.

| File | Fluent Emoji asset |
|---|---|
| `books.png` | Books (`assets/Books/3D/books_3d.png`) |
| `open-book.png` | Open book (`assets/Open book/3D/open_book_3d.png`) |
| `test-tube.png` | Test tube (`assets/Test tube/3D/test_tube_3d.png`) |
| `microscope.png` | Microscope (`assets/Microscope/3D/microscope_3d.png`) |
| `graduation-cap.png` | Graduation cap (`assets/Graduation cap/3D/graduation_cap_3d.png`) |
| `briefcase.png` | Briefcase (`assets/Briefcase/3D/briefcase_3d.png`) |
| `rocket.png` | Rocket (`assets/Rocket/3D/rocket_3d.png`) |
| `puzzle.png` | Puzzle piece (`assets/Puzzle piece/3D/puzzle_piece_3d.png`) |
| `memo.png` | Memo (`assets/Memo/3D/memo_3d.png`) |
| `clipboard.png` | Clipboard (`assets/Clipboard/3D/clipboard_3d.png`) |
| `laptop.png` | Laptop (`assets/Laptop/3D/laptop_3d.png`) |
| `brain.png` | Brain (`assets/Brain/3D/brain_3d.png`) |
| `clapper.png` | Clapper board (`assets/Clapper board/3D/clapper_board_3d.png`) |
| `video-camera.png` | Video camera (`assets/Video camera/3D/video_camera_3d.png`) |
| `page.png` | Page with curl (`assets/Page with curl/3D/page_with_curl_3d.png`) |
| `bookmark-tabs.png` | Bookmark tabs (`assets/Bookmark tabs/3D/bookmark_tabs_3d.png`) |
| `file-folder.png` | File folder (`assets/File folder/3D/file_folder_3d.png`) |
| `open-folder.png` | Open file folder (`assets/Open file folder/3D/open_file_folder_3d.png`) |
| `speech-balloon.png` | Speech balloon (`assets/Speech balloon/3D/speech_balloon_3d.png`) |
| `calendar.png` | Spiral calendar (`assets/Spiral calendar/3D/spiral_calendar_3d.png`) |
| `trophy.png` | Trophy (`assets/Trophy/3D/trophy_3d.png`) |
| `sports-medal.png` | Sports medal (`assets/Sports medal/3D/sports_medal_3d.png`) |
| `first-place.png` | 1st place medal (`assets/1st place medal/3D/1st_place_medal_3d.png`) |
| `coin.png` | Coin (`assets/Coin/3D/coin_3d.png`) |
| `fire.png` | Fire (`assets/Fire/3D/fire_3d.png`) |
| `bell.png` | Bell (`assets/Bell/3D/bell_3d.png`) |
| `satellite.png` | Satellite antenna (`assets/Satellite antenna/3D/satellite_antenna_3d.png`) |
| `red-circle.png` | Red circle (`assets/Red circle/3D/red_circle_3d.png`) |
| `tools.png` | Hammer and wrench (`assets/Hammer and wrench/3D/hammer_and_wrench_3d.png`) |
| `construction.png` | Construction (`assets/Construction/3D/construction_3d.png`) |
| `locked.png` | Locked (`assets/Locked/3D/locked_3d.png`) |
| `unlocked.png` | Unlocked (`assets/Unlocked/3D/unlocked_3d.png`) |
| `party-popper.png` | Party popper (`assets/Party popper/3D/party_popper_3d.png`) |
| `magnifier.png` | Magnifying glass tilted left (`assets/Magnifying glass tilted left/3D/magnifying_glass_tilted_left_3d.png`) |
| `sparkles.png` | Sparkles (`assets/Sparkles/3D/sparkles_3d.png`) |
| `robot.png` | Robot (`assets/Robot/3D/robot_3d.png`) |
| `check.png` | Check mark button (`assets/Check mark button/3D/check_mark_button_3d.png`) |
| `link.png` | Link (`assets/Link/3D/link_3d.png`) |
| `light-bulb.png` | Light bulb (`assets/Light bulb/3D/light_bulb_3d.png`) |
| `bullseye.png` | Bullseye (`assets/Bullseye/3D/bullseye_3d.png`) |
| `pencil.png` | Pencil (`assets/Pencil/3D/pencil_3d.png`) |
| `bar-chart.png` | Bar chart (`assets/Bar chart/3D/bar_chart_3d.png`) |
| `compass.png` | Compass (`assets/Compass/3D/compass_3d.png`) |
| `gear.png` | Gear (`assets/Gear/3D/gear_3d.png`) |
| `studio-microphone.png` | Studio microphone (`assets/Studio microphone/3D/studio_microphone_3d.png`) |
| `card-file-box.png` | Card file box (`assets/Card file box/3D/card_file_box_3d.png`) |
| `artist-palette.png` | Artist palette (`assets/Artist palette/3D/artist_palette_3d.png`) |
| `megaphone.png` | Megaphone (`assets/Megaphone/3D/megaphone_3d.png`) |
| `chart-increasing.png` | Chart increasing (`assets/Chart increasing/3D/chart_increasing_3d.png`) |
| `shield.png` | Shield (`assets/Shield/3D/shield_3d.png`) |
| `cloud.png` | Cloud (`assets/Cloud/3D/cloud_3d.png`) |
| `globe.png` | Globe with meridians (`assets/Globe with meridians/3D/globe_with_meridians_3d.png`) |
| `mobile-phone.png` | Mobile phone (`assets/Mobile phone/3D/mobile_phone_3d.png`) |
| `electric-plug.png` | Electric plug (`assets/Electric plug/3D/electric_plug_3d.png`) |
| `stethoscope.png` | Stethoscope (`assets/Stethoscope/3D/stethoscope_3d.png`) |
| `abacus.png` | Abacus (`assets/Abacus/3D/abacus_3d.png`) |
| `hot-beverage.png` | Hot beverage (`assets/Hot beverage/3D/hot_beverage_3d.png`) |
| `video-game.png` | Video game (`assets/Video game/3D/video_game_3d.png`) |
| `desktop-computer.png` | Desktop computer (`assets/Desktop computer/3D/desktop_computer_3d.png`) |
| `keyboard.png` | Keyboard (`assets/Keyboard/3D/keyboard_3d.png`) |
| `dna.png` | Dna (`assets/Dna/3D/dna_3d.png`) |
| `atom.png` | Atom symbol (`assets/Atom symbol/3D/atom_symbol_3d.png`) |
| `world-map.png` | World map (`assets/World map/3D/world_map_3d.png`) |
| `money-bag.png` | Money bag (`assets/Money bag/3D/money_bag_3d.png`) |
| `sun-behind-cloud.png` | Sun behind cloud (`assets/Sun behind cloud/3D/sun_behind_cloud_3d.png`) |
| `triangular-ruler.png` | Triangular ruler (`assets/Triangular ruler/3D/triangular_ruler_3d.png`) |
| `balance-scale.png` | Balance scale (`assets/Balance scale/3D/balance_scale_3d.png`) |
| `battery.png` | Battery (`assets/Battery/3D/battery_3d.png`) |
| `shopping-cart.png` | Shopping cart (`assets/Shopping cart/3D/shopping_cart_3d.png`) |
| `ambulance.png` | Ambulance (`assets/Ambulance/3D/ambulance_3d.png`) |
| `credit-card.png` | Credit card (`assets/Credit card/3D/credit_card_3d.png`) |
| `handshake.png` | Handshake (`assets/Handshake/3D/handshake_3d.png`) |
| `office-building.png` | Office building (`assets/Office building/3D/office_building_3d.png`) |
| `input-numbers.png` | Input numbers (`assets/Input numbers/3D/input_numbers_3d.png`) |
| `musical-notes.png` | Musical notes (`assets/Musical notes/3D/musical_notes_3d.png`) |
| `film-frames.png` | Film frames (`assets/Film frames/3D/film_frames_3d.png`) |
| `crystal-ball.png` | Crystal ball (`assets/Crystal ball/3D/crystal_ball_3d.png`) |
| `mechanical-arm.png` | Mechanical arm (`assets/Mechanical arm/3D/mechanical_arm_3d.png`) |
| `alarm-clock.png` | Alarm clock (`assets/Alarm clock/3D/alarm_clock_3d.png`) |
| `stopwatch.png` | Stopwatch (`assets/Stopwatch/3D/stopwatch_3d.png`) |
| `scroll.png` | Scroll (`assets/Scroll/3D/scroll_3d.png`) |
| `notebook.png` | Notebook (`assets/Notebook/3D/notebook_3d.png`) |
| `key.png` | Key (`assets/Key/3D/key_3d.png`) |
| `package.png` | Package (`assets/Package/3D/package_3d.png`) |
| `game-die.png` | Game die (`assets/Game die/3D/game_die_3d.png`) |
| `trophy.png` | Trophy (`assets/Trophy/3D/trophy_3d.png`) |
| `scroll.png` | Scroll (`assets/Scroll/3D/scroll_3d.png`) |
| `party-popper.png` | Party popper (`assets/Party popper/3D/party_popper_3d.png`) |
| `open-folder.png` | Open file folder (`assets/Open file folder/3D/open_file_folder_3d.png`) |
| `briefcase.png` | Briefcase (`assets/Briefcase/3D/briefcase_3d.png`) |
| `first-place.png` | 1st place medal (`assets/1st place medal/3D/1st_place_medal_3d.png`) |
| `page.png` | Page facing up (`assets/Page facing up/3D/page_facing_up_3d.png`) |

## coin.png (customised)
`coin.png` and `128/coin.png` are the Fluent Emoji 3D coin (MIT) with the central emblem replaced by a raised gold blackbuck silhouette taken from the TapTap brand mark. The original is kept as `coin-fluent-original.png`.
