self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    // Non-JSON payload (e.g. DevTools' "Push" test button sends plain
    // text) — our real backend always sends JSON, but an uncaught throw
    // here would silently drop the notification instead of showing one.
    data = { body: event.data ? event.data.text() : "" };
  }

  event.waitUntil(
    self.registration.showNotification(data.title || "Notification", {
      body: data.body,
      icon: "/favicon.ico",
      tag: data.tag,
      requireInteraction: data.requireInteraction === true,
      data: { url: data.url || "/" },
    }),
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = event.notification.data.url;

  event.waitUntil(
    clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then((windowClients) => {
        for (const client of windowClients) {
          if ("focus" in client) {
            client.postMessage({ type: "navigate", url });
            return client.focus();
          }
        }
        return clients.openWindow(url);
      }),
  );
});
